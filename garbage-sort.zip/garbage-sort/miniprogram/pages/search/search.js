// pages/search/search.js
wx.cloud.init({
  env: 'garbage-sort-nhb3s'
})
const db = wx.cloud.database({
  env: 'garbage-sort-nhb3s'
});
const globalData = require('../../common/js/data.js');
const keywords = globalData.keywords;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    indexPageHidden: false,
    // 搜索框状态
    inputShowed: true,
    //显示结果view的状态
    viewShowed: false,
    // 搜索框值
    inputVal: "",
    //搜索渲染推荐数据
    garbageList: [],

    btnWidth: 300, //删除按钮的宽度单位
    startX: "", //收支触摸开始滑动的位置
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    //初始化界面
    that.initEleWidth();
  },
  // 隐藏搜索框样式
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false,
      indexPageHidden: true
    });
  },
  // 清除搜索框值
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
  },
  // 键盘抬起事件2
  inputTyping: function (e) {
    var that = this;
    const detail = e.detail;
    const inputValue = e.detail.value;
    if (inputValue == '') {
      return;
    }
    if (inputValue.charAt(inputValue.length - 1) != " "){
      that.setData({
        viewShowed: false,
        inputVal: inputValue
      });
      console.log(inputValue);
      db.collection('garbage').where({
        garbagename: new db.RegExp({
          regexp: inputValue
        })
      }).get().then(res => {
        // res.data 包含该记录的数据
        var keys = inputValue.split('');
        if (res.data.length > 0){
          that.setData({
            garbageList: res.data
          })
        } else if (detail.cursor > 0 && keys.length > 1) {
          keys.forEach(function (item, index) {
            if (keywords.indexOf(item) != -1) {
              db.collection('garbage').where({
                garbagename: new db.RegExp({
                  regexp: item
                })
              }).get().then(res2 => {
                const result = [];
                res2.data.forEach(function (item2, index2) {
                  if (result.length > 0) {
                    result.forEach(function (item3, index3) {
                      // console.log(item2);
                      // console.log(item3);
                      if (item2.garbagename != item3.garbagename) {
                        result.push(item2);
                      }
                    })
                  } else {
                    result.push(item2);
                  }
                })
                let res = []
                for (let i = 0; i < result.length; i++) {
                  if (res.indexOf(result[i]) === -1) {
                    res.push(result[i])
                  }
                }
                that.setData({
                  garbageList: res
                })
              }).catch(err2 => {
                console.log(err2);
              })
            }
          })
        }
      }).catch(err => {
        console.log(err);
      })
    }
  },
  // 获取选中推荐列表中的值
  btn_name: function (e) {
    var that = this;
    var sortid = e.currentTarget.dataset.sortid;
    var garbagename = e.currentTarget.dataset.garbagename;

    that.hideInput();

    that.setData({
      viewShowed: true,
    });
    wx.navigateTo({
      url: '../../pages/show-tfyq/show-tfyq?sortid=' + e.currentTarget.dataset.sortid + '&resultHidden=' + false + '&garbagename=' + garbagename,
    })
  },

  //获取元素自适应后的实际宽度
  getEleWidth: function (w) {
    var real = 0;
    try {
      var res = wx.getSystemInfoSync().windowWidth;
      var scale = (750 / 2) / (w / 2); //以宽度750px设计稿做宽度的自适应
      real = Math.floor(res / scale);
      return real;
    } catch (e) {
      return false;
      // Do something when catch error
    }
  },
  initEleWidth: function () {
    var btnWidth = this.getEleWidth(this.data.btnWidth);
    this.setData({
      btnWidth: btnWidth
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})