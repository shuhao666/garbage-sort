// pages/base/base.js
wx.cloud.init({
  env: 'garbage-sort-nhb3s'
})
const db = wx.cloud.database({
  env: 'garbage-sort-nhb3s'
});

const globalData = require('../../common/js/data.js');
const sortImgs = globalData.sortImgs;
const sortDescs = globalData.sortDescs;
const khsws = globalData.khsws;
const yhljs = globalData.yhljs;
const sljs = globalData.sljs;
const gljs = globalData.gljs;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    images: sortImgs,
    sortDescs: sortDescs
  },
  onSearch:function(e){
    wx.navigateTo({
      url: '../../pages/search/search',
    })
  }, 
  sortClick: function(e){
    wx.navigateTo({
      url: '../../pages/show-tfyq/show-tfyq?sortid=' + e.currentTarget.dataset.sortid + '&resultHidden=' + true,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})