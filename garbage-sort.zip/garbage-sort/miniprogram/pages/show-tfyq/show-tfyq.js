// pages/show-tfyq/show-tfyq.js
const globalData = require('../../common/js/data.js');
const sortNames = globalData.sortNames;
const sortImgs = globalData.sortImgs;
const sortDescs = globalData.sortDescs;
const tfyqs = globalData.tfyqs;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    resultHidden: false,
    sortid:'sort-0',
    sortName: sortNames[0],
    sortImg: sortImgs[0],
    sortDesc: sortDescs[0],
    tfyq: tfyqs[0],
    tfznfileid:'cloud://garbage-sort-nhb3s.6761-garbage-sort-nhb3s/garbage-sort-guide.jpg',
    garbagename: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const sortid = options.sortid;
    const resultHidden = options.resultHidden == 'false' ? false : true;
    const garbagename = options.garbagename;
    if (sortid != "" && sortid != undefined){
      const index = sortid.substring(5);
      this.setData({
        resultHidden: resultHidden,
        sortid: sortid,
        sortImg: sortImgs[index],
        sortDesc: sortDescs[index],
        sortName: sortNames[index],
        tfyq: tfyqs[index],
        garbagename: garbagename
      });
    }else{
      return;
    }
  },
  downloadFile: function (e) {
    wx.cloud.downloadFile({
      fileID: e.target.dataset.fileid,
    }).then(res => {
      // get temp file path
      //保存图片到手机相册
      wx.saveImageToPhotosAlbum({
        filePath: res.tempFilePath,
        success(res) {
          wx.showToast({
            title: '保存成功',
          })
        }
      })
    }).catch(error => {
      // handle error
      console.log(error);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})